<?php

$html['module'] = 'shop_product';

$html['content'] = html_array('shop/product_text',$page['shop_products'][0]);