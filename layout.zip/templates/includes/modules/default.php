<div class="col-xs-12">
	<h1><?=$page['name']?></h1>
	<div class="content">
		<?=$html['content']?>
	</div>
</div>