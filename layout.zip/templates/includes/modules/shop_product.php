<div class="col-xs-12">
	<?=$html['content']?>
</div>